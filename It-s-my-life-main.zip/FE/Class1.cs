﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FE
{
    class Class1
    {
        public static int cl1 = 0, cl2 = 0, cl3 = 0, cl4 = 0, cl5 = 0, cl6 = 0, cl7 = 0, cl8 = 0, cl9 = 0, cl0 = 0, fcl = 0,
        cl11 = 0, cl22 = 0, cl33 = 0, cl44 = 0, cl55 = 0, cl66 = 0, cl77 = 0, cl88 = 0, cl99 = 0,
            cl111, cl222, cl333, cl444, cl555, cl666, cl777, cl888, cl999;

    }
}
